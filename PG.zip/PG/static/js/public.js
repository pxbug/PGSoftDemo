// JavaScript Document
$(function() {
	//入场动画 初始
	var isScroll = {
		/*初始化*/
		init: function(_el) {
			this.start(_el);
			$(window).on('scroll', function() {
				isScroll.start(_el)
			});
		},
		/*开始*/
		start: function(_el) {
			var self = this;
			$(_el).each(function() {
				var _self = $(this);
				/*滚动高度*/
				var isScrollTop = $(window).scrollTop();
				/*滚动视度*/
				var isWindowHeiget = $(window).height() * 0.8;
				/**/
				var _class = $(this).data('animation');
				if (isScrollTop + isWindowHeiget > $(this).offset().top) {
					_self.addClass(_class);
				}
			});
		}
	};
	isScroll.init('.anim'); /*页面元素入场动画*/
	isScroll.init('.animLeft'); /*页面元素入场动画*/
	isScroll.init('.animRight'); /*页面元素入场动画*/
	isScroll.init('.animBig'); /*页面元素入场动画*/
	isScroll.init('.animFade'); /*页面元素入场动画*/


	//数字跳转
	$.fn.countTo = function(options) {
		options = options || {};

		return $(this).each(function() {
			// set options for current element
			var settings = $.extend({}, $.fn.countTo.defaults, {
				from: $(this).data('from'),
				to: $(this).data('to'),
				speed: $(this).data('speed'),
				refreshInterval: $(this).data('refresh-interval'),
				decimals: $(this).data('decimals')
			}, options);

			// how many times to update the value, and how much to increment the value on each update
			var loops = Math.ceil(settings.speed / settings.refreshInterval),
				increment = (settings.to - settings.from) / loops;

			// references & variables that will change with each update
			var self = this,
				$self = $(this),
				loopCount = 0,
				value = settings.from,
				data = $self.data('countTo') || {};

			$self.data('countTo', data);

			// if an existing interval can be found, clear it first
			if (data.interval) {
				clearInterval(data.interval);
			}
			data.interval = setInterval(updateTimer, settings.refreshInterval);

			// initialize the element with the starting value
			render(value);

			function updateTimer() {
				value += increment;
				loopCount++;

				render(value);

				if (typeof(settings.onUpdate) == 'function') {
					settings.onUpdate.call(self, value);
				}

				if (loopCount >= loops) {
					// remove the interval
					$self.removeData('countTo');
					clearInterval(data.interval);
					value = settings.to;

					if (typeof(settings.onComplete) == 'function') {
						settings.onComplete.call(self, value);
					}
				}
			}

			function render(value) {
				var formattedValue = settings.formatter.call(self, value, settings);
				$self.html(formattedValue);
			}
		});
	};

	$.fn.countTo.defaults = {
		from: 0, // the number the element should start at
		to: 0, // the number the element should end at
		speed: 1000, // how long it should take to count between the target numbers
		refreshInterval: 100, // how often the element should be updated
		decimals: 0, // the number of decimal places to show
		formatter: formatter, // handler for formatting the value before rendering
		onUpdate: null, // callback method for every time the element is updated
		onComplete: null // callback method for when the element finishes updating
	};

	function formatter(value, settings) {
		return value.toFixed(settings.decimals);
	}



	// custom formatting example
	$('#count-number').data('countToOptions', {
		formatter: function(value, options) {
			return value.toFixed(options.decimals).replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
		}
	});

	// start all the timers

	if ($(".dataList").length > 0) {
		var data_h = $(".dataList").offset().top - $(window).height();

		//console.log("设定的数值："+data_h);
		$(window).scroll(function() {

			if ($(window).scrollTop() > data_h) {

				$('.timer').each(count);
			};
		});

	};

	function count(options) {
		var $this = $(this);
		options = $.extend({}, options || {}, $this.data('countToOptions') || {});
		$this.countTo(options);
	}

	/*头部固定*/
	
  $(window).scroll(function() {
	if ($(window).scrollTop() > 44) {
		console.log("aaa");
		$(".headerW").addClass("headerB");
	} else {
		$(".headerW").removeClass("headerB");
	
	};
	});

	/*菜单 展开收起*/
	$(".header .c-switch").click(function() {
		$(".navW").addClass("show");
	});
	$(".navW .close").click(function() {
		$(".navW").removeClass("show");
	});
	
	
	if ($(".swiper-game-1").length > 0) {
		var swiper_game_1 = new Swiper('.swiper-game-1', {
			speed: 1000,
			loop:true,
			slidesPerView: 10, 
			autoplay: {
				delay: 500,
				disableOnInteraction: false,
			},
			breakpoints: {
			        828: {
			          slidesPerView: 5, 
			        }
			 },
		});
	};
	
	
	
	if ($(".swiper-game-2").length > 0) {
		var swiper_game_2 = new Swiper('.swiper-game-2', {
			speed: 1000,
			loop:true,
			slidesPerView: 10, 
			autoplay: {
				delay: 500,
				reverseDirection: true,
				disableOnInteraction: false,
			},
			breakpoints: {
			        828: {
			          slidesPerView: 5, 
			        }
			 },
		});
	};
	
	if ($(".swiper-game-3").length > 0) {
		var swiper_game_3 = new Swiper('.swiper-game-3', {
			speed: 1000,
			loop:true,
			slidesPerView: 10, 
			autoplay: {
				delay: 500,
				disableOnInteraction: false,
			},
			breakpoints: {
			        828: {
			          slidesPerView: 5, 
			        }
			 },
		});
	};
	
	if ($(".swiper-game-4").length > 0) {
		var swiper_game_4 = new Swiper('.swiper-game-4', {
			speed: 1000,
			loop:true,
			slidesPerView: 10, 
			autoplay: {
				delay: 500,
				reverseDirection: true,
				disableOnInteraction: false,
			},
			breakpoints: {
			        828: {
			          slidesPerView: 5, 
			        }
			 },
		});
	};
	
	if ($(".swiper-banner").length > 0) {
		var swiper_banner = new Swiper('.swiper-banner', {
			speed: 500,
			loop:true,
			autoplay: {
				delay:5000,
				disableOnInteraction: false,
			},
			pagination: {
				el: '.swiper-banner .swiper-pagination',
				clickable: true,
			},
			navigation: {
							nextEl: '.swiper-banner .btnPrev',
							prevEl: '.swiper-banner .btnNext',
						},
			
		});
	};
	
	
	
	$(".gameList ul li .pics").click(function(){
		$("body").append(`
		   <div class="pIframeBox">
		   	<div class="pIframeCon">
		   		
		   		<div class="conB">
		   		    <div class="close"></div>
		   			<div class="conC">
		   				<iframe class="iframe" border="0" src="`+
						$(this).attr("rel")
						+`"></iframe>
		   			</div>
		   		</div>
		   		
		   	</div>
		   </div>
		`);
		
		$(".pIframeBox .close ").click(function(){
			$(".pIframeBox").remove();
		});
		
	});
	
	

});
